#01
data <- read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

popmn <- mean(Weight.kg.)
popvar <- var(Weight.kg.)

#02
sample <- c()
n <- c()

for(i in 1:25){
  s <- sample(Weight.kg.,6,replace = TRUE)
  sample <- cbind(sample,s)
  n <- c(n,paste('S',i))
}

sample
n

colnames(sample)=n
fix(sample)

s.mean <- apply(sample,2,mean)
s.mean
s.var <- apply(sample,2,var)
s.var

#03
samplemean <- mean(s.mean)
samplevars <- var(s.mean)

popmn
samplemean

truevar = popvar/5
samplevars
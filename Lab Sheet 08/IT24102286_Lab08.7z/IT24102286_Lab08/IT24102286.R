# Setting the working directory
setwd("C:\\Users\\it24102308\\Desktop\\IT24102308")

data <- read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(data)
attach(data)